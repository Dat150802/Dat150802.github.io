KLC Nội bộ – Frontend v2

• index.html: giao diện mới (Dashboard có biểu đồ, tháng/năm; Khách hàng với nguồn khách mới + ô chi tiết; CSKH có danh sách khách đã CSKH)
• .nojekyll: để GitHub Pages phục vụ file tĩnh như nguyên bản.

Cấu hình đã gắn sẵn:
- Google Client ID: 229964671691-jvq8pstlajqa9v6g0rhfi0u8ei39453u.apps.googleusercontent.com
- Apps Script Web App URL (doPost): https://script.google.com/macros/s/AKfycbxscUm2o0q70dsQm3mERQyyZWejd2TmQREfqXZ6qkbQtQYx-OWuB5BDFmBpBJj6_ebw/exec

Triển khai:
1) Tải file ZIP cùng thư mục này lên GitHub repo GitHub Pages của bạn (dat150802/dat150802.github.io) nhánh main, ở thư mục gốc. Ghi đè index.html cũ.
2) Chờ deploy xong (Deployments -> github-pages), refresh trang.
